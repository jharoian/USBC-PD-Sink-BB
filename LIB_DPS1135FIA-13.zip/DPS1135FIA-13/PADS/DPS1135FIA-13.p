*PADS-LIBRARY-PART-TYPES-V9*

DPS1135FIA-13 DPS1135FIA13 I ANA 9 1 0 0 0
TIMESTAMP 2025.07.28.04.40.52
"Manufacturer_Name" Diodes Incorporated
"Manufacturer_Part_Number" DPS1135FIA-13
"Mouser Part Number" 621-DPS1135FIA-13
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diodes-Incorporated/DPS1135FIA-13?qs=gZXFycFWdANS9y4GcBigag%3D%3D
"Arrow Part Number" DPS1135FIA-13
"Arrow Price/Stock" https://www.arrow.com/en/products/dps1135fia-13/diodes-incorporated?region=nac
"Description" Power Switch ICs - Power Distribution PD Switch
"Datasheet Link" https://www.diodes.com/assets/Datasheets/DPS1135.pdf
"Geometry.Height" 0.85mm
GATE 1 14 0
DPS1135FIA-13
1 0 U IN
4 0 U EN
5 0 U FRS
6 0 U GND
7 0 U VREG
8 0 U DISC1
9 0 U DISC2
10 0 U FAULTB
11 0 U IMON
12 0 U DV/DT
13 0 U ILIM
14 0 U VLIM
15 0 U OUT
18 0 U SRC

*END*
*REMARK* SamacSys ECAD Model
6680290/1492997/2.50/14/3/Integrated Circuit
